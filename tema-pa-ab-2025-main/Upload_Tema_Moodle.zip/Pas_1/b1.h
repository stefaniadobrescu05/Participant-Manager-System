#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

typedef enum statut{LORD, CAVALER, AVENTURIER} statut;

typedef struct participant
{
   char* nume;
   int var;
   float exp;
   statut s;
}participant;

typedef struct Node
{
    participant p;
    struct Node* next;
}Node;

typedef struct
{
    Node *front, *rear;
}queue;

queue* createQueue();

Node* createNode(participant p);

void enQueue(queue* q, participant p);

int isEmpty(queue* q);

void freeQueue(queue* q);

char* process_name(char nume_linie[100]);

statut statut_from_string(char* s);

char* statut_to_string(statut s);

participant parse_line(char* linie);