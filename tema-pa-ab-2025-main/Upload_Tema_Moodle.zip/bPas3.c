/*#include "bPas3.h"

//daca vreau sa sterg un nod cu doi copii am nevoie de copilul
//sau din stanga (acolo este valoarea mai mica)
TreeNode* minValueNode(TreeNode* root){
    // mergem cât mai mult spre stânga (acolo sunt valorile cele mai mici)
    while (root && root->left)
        root = root->left;
    return root; // returnăm nodul cel mai mic găsit
}

void update_bst(TreeNode** root, FILE *f){
    char linie[256];

    while (fgets(linie, sizeof(linie), f)){
        participant p=parse_line(linie);
        if (p.s==LORD){//aici se verfifca daca statutul este de lord 
            *root = delete_node(*root, p.exp);
            free(p.nume);
        }
    }
}

TreeNode* delete_node(TreeNode* root, float exp){
    //printf("delete_node called\n");
    if (root==NULL) 
        return NULL; // bază de recursie: arbore gol

    //daca experienta primita ca parametru este mai mica decat exp nodului in care suntem
    if (exp<root->p.exp){
        root->left=delete_node(root->left, exp);
        //mergem in stanga
    }
    else if(exp>root->p.exp){
        // Căutăm în subarborele drept dacă cheia e mai mare
        root->right=delete_node(root->right, exp);
    }
    else{
        // Am găsit nodul cu experiența căutată
        // Caz 1: Nu are copil sau are doar copil dreapta
        if (root->left==NULL){
            TreeNode* temp=root->right; // putem muta dreptul în locul său
            free(root->p.nume);           // eliberăm numele alocat dinamic
            free(root);                   // eliberăm nodul în sine
            return temp;                  // întoarcem noua legătură
        }
        // Caz 2: Nu are copil sau are doar copil stânga
        else if (root->right==NULL){
            TreeNode* temp=root->left; // putem muta stânga în locul său
            free(root->p.nume);
            free(root);
            return temp;
        }

        // Caz 3: Are doi copii
        // Căutăm succesorul (cel mai mic nod din subarborele drept)
        TreeNode* minNode=minValueNode(root->right);
            // Salvează exp înainte de a modifica root
            float min_exp = minNode->p.exp;

            // Copiază datele
            free(root->p.nume);
            root->p.nume = strdup(minNode->p.nume);
            root->p.exp = min_exp;
            root->p.var = minNode->p.var;
            root->p.s = minNode->p.s;

            // Șterge nodul duplicat folosind valoarea originală
            root->right = delete_node(root->right, min_exp);

    }
    if (root->right == root){ 
        printf(" root->right pointează către root! Ciclu creat!\n");
    }

    // Returnăm rădăcina curentă (eventual modificată)
    return root;
}
*/