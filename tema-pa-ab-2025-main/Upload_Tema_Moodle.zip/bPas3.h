/*#include <stdio.h>
#include <stdlib.h>
#include "bst.h"

#ifndef BPAS3_H
#define BPAS3_H

TreeNode* minValueNode(TreeNode* root);

void update_bst(TreeNode** root, FILE *f);

TreeNode* delete_node(TreeNode* root, float exp);



#endif*/