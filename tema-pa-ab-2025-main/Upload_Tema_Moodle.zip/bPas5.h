#include <stdio.h>
#include <stdlib.h>
#include "heap.h"

#ifndef BPAS5_H
#define BPAS5_H

void update_exp(MaxHeap* h);

#endif