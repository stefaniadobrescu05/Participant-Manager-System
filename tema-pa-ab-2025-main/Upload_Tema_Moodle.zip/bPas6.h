#include <stdio.h>
#include <stdlib.h>
#include "bPas5.h"

#ifndef BPAS6_H
#define BPAS6_H

heap_elements* delete_max(MaxHeap* h);

#endif