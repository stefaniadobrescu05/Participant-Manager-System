#include "bts.h"

TreeNode* insert(TreeNode* root, participant p) //primeste ca parametrii root-ul de tip TreeNode si variabila p care este un participant
                                                //participentul este descris in biblioteca bPas1 si prezinta tot ce caracterizeaza un participat
                                                //impartirea in doi arbori dupa statut urmeaza sa fie facuta in main
//functia porneste cu un arbore care se presupune ca este gol si insereza in root primul element din coada, inainte creand spatiu pentru el
 {
    if (root==NULL) 
    {
        TreeNode* node=(TreeNode*)malloc(sizeof(TreeNode));
        node->p=p;
        node->left=NULL;
        node->right=NULL;
        return node;
    }

    if (p.exp<root->p.exp)  //cand arborele deja nu mai este gol, asigura, in functie de experienta caliataea de bts prin comparatii prin pasi recursivi
        root->left=insert(root->left, p);
    else if(p.exp>=root->p.exp)
        root->right=insert(root->right, p);
    return root;
}

void complete_inorder(TreeNode* root, FILE* f) 
{
    if(root==NULL) 
    return;

    complete_inorder(root->right, f);
    //printf("DEBUG: %.2f %s\n", root->p.exp, root->p.nume); // afișare în terminal
    fprintf(f, "%s %.2f %d %s\n", root->p.nume, root->p.exp, root->p.var, statut_to_string(root->p.s));
    complete_inorder(root->left, f);
}

void free_bst(TreeNode* root) 
{
    if(root==NULL) 
    return;
    free_bst(root->left);
    free_bst(root->right);
    free(root->p.nume);
    free(root);
}


