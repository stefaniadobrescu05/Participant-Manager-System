#include <stdio.h>
#include <stdlib.h>
#include "coada.h"
#include "bPas1.h"

#ifndef BTS_H
#define BTS_H

typedef struct TreeNode {
    participant p;
    struct TreeNode* left;
    struct TreeNode* right;
} TreeNode;

TreeNode* insert(TreeNode* root, participant p);

void inorder(TreeNode* root, FILE* f);

void free_bst(TreeNode* root);

#endif