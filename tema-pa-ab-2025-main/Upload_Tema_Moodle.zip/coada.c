#include "coada.h"

queue* createQueue(){//am  creat o coada in care urmeaza sa adaug elemente din fisier
    queue* q;
    q=(queue*)malloc(sizeof(queue));
    if (q==NULL){
        printf("Eroare la alocarea memoriei!\n");
        return NULL;
    }

    if(q==NULL)
        return NULL;

    q->front=q->rear=NULL;

    return q;
}

void freeQueue(queue* q){
    Node* temp;
    while (q->front){
        temp = q->front;
        q->front = q->front->next;
        free(temp->p.nume);
        free(temp);
    }

    free(q);
}

void enQueue(queue* q, participant p) {
    Node* newNode = createNode(p);
    if (!newNode) return;  

    if (isEmpty(q)) {
        q->front = q->rear = newNode;
    } 
    else {
        q->rear->next = newNode;
        q->rear = newNode;
    }
}

participant dequeue(queue* q){//fct care soate cate un elem pe rand din coada pentrua putea fi pus in bst
    if (q->front==NULL){
        fprintf(stderr, "Coada este goală.\n");
        exit(1);
    }

    Node* temp=q->front;
    participant p=temp->p; // păstrăm datele

    q->front=q->front->next;
    if (q->front==NULL) 
    q->rear = NULL;

    free(temp);

    return p;
}

int isEmpty(queue* q){
    return q->front == NULL;
}