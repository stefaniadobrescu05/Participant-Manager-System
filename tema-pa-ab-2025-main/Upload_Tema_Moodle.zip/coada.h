#include <stdio.h>
#include <stdlib.h>
#include "lista.h" //daca in lista.h am inclus bib pas1 pentru ca acolo am definita structura participant 
                    //mai trb apelata si aici biblioteca cu structua participant?

#ifndef COADA_H
#define COADA_H

typedef struct
{
    Node *front, *rear;
}queue;

queue* createQueue();

void enQueue(queue* q, participant p);

int isEmpty(queue* q);

void freeQueue(queue* q);

participant dequeue(queue* q);

#endif