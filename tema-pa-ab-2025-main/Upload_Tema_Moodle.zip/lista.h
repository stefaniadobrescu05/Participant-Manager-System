#include <stdio.h>
#include <stdlib.h>
#include "bPas1.h"

#ifndef LISTA_H
#define LISTA_H

typedef struct Node
{
    participant p;
    struct Node* next;
}Node;

Node* createNode(participant p);

#endif